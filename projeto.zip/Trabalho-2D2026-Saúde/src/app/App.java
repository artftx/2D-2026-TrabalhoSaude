
package app;


public class App {

   //so para deixar a tela visivel
    public static void main(String[] args) {
       view.MenuTela telaInicial = new view.MenuTela();
       telaInicial.setVisible(true);
       
    }
    
}
