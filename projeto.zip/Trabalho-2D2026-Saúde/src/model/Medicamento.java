
package model;
import java.util.ArrayList;
import java.util.List;

public class Medicamento {
    private String nome;
    private int quantidade;
    private String validade;

    // Lista para salvar os dados na memória
    public static List<Medicamento> listaMedicamentos = new ArrayList<>();

    //erro que tava dando
    public Medicamento(String nome, int quantidade, String validade) {
        this.nome = nome;
        this.quantidade = quantidade;
        this.validade = validade;
        
    }

    // para tabela ler os dados
    public String getNome() { return nome; }
    public int getQuantidade() { return quantidade; }
    public String getValidade() { return validade; }
    
    
}



